<?php
/*Se encarga de eliminar calificaciones*/
include("conexion.php");
include("barra_lateral.php");
$usuarioingresado = $_SESSION['usuarioingresando'];
$pagina = $_GET['pag'];
$id = $_GET['id'];

mysqli_query($conn, "DELETE FROM productos2 WHERE id='$id'");
header("Location:calificaciones_tabla.php?pag=$pagina");

?>