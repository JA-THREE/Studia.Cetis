<?php
/*Se encarga de modificar las calificaciones*/ 
include("conexion.php");
include("calificaciones_tabla.php");

$pagina = $_GET['pag'];
$id = $_GET['id'];

$querybuscar = mysqli_query($conn, "SELECT * FROM productos2 WHERE id = '$id'");
 
while($mostrar = mysqli_fetch_array($querybuscar))
{	
	$proid 		= $mostrar['id'];
	$proesp 	= $mostrar['español'];
	$promat 	= $mostrar['matematicas'];
	$profis 	= $mostrar['fisica'];
	$propro 	= $mostrar['productos_id'];
}
?>
<html>
<body>
<div class="caja_popup2">
<form class="contenedor_popup" method="POST">
<table>
<tr><th colspan="2">Modificar Calificaciones</th></tr>	
<tr> 
<td><b>Id: </b></td>
<td><input class="CajaTexto" type="number" name="txtid" value="<?php echo $proid;?>" readonly></td>
</tr>
<tr> 
<td><b>Español: </b></td>
<td><input class="CajaTexto" type="text" name="txtnom" value="<?php echo $proesp;?>" required></td>
</tr>
<tr> 
<td><b>Matematicas: </b></td>
<td><input class="CajaTexto" type="text" name="txtdes" value="<?php echo $promat;?>" required></td>
</tr>
<tr> 
<td><b>Fisica: </b></td>
<td><input class="CajaTexto" type="text" name="txtpre" value="<?php echo $profis;?>" required ></td>
</tr>
<tr> 
<td><b>Alumno: </b></td>
<td>
<select name="txtpro" class='CajaTexto'>

<?php	
$qrproductos2 = mysqli_query($conn, "SELECT * FROM productos ");
while($mostrarpro = mysqli_fetch_array($qrproductos2)) 
{ 
if($mostrarpro['id']==$propro)
{
echo '<option selected="selected" value="'.$mostrarpro['id'].'">' .$mostrarpro['nombre']. '</option>';
}
else
{
echo '<option value="'.$mostrarpro['id'].'">' .$mostrarpro['nombre']. '</option>';
}
}		
?> 

</select>
</td>
</tr>
<tr>
<td colspan="2" >
<?php echo "<a class='BotonesTeam' href=\"calificaciones_tabla.php?pag=$pagina\">Cancelar</a>";?>&nbsp;
<input class='BotonesTeam' type="submit" name="btnregistrar" value="Modificar" onClick="javascript: return confirm('¿Deseas modificar las calificaciones?');">
</td>
</tr>
</table>
</form>
</div>
</body>
</html>

<?php
	
if(isset($_POST['btnregistrar']))
{    
	$proid1 	= $_POST['txtid'];
	$proesp1 	= $_POST['txtesp'];
	$promat1	= $_POST['txtmat'];
	$profis1 	= $_POST['txtfis'];
	$propro1 	= $_POST['txtpro'];
      
$querymodificar = mysqli_query($conn, "UPDATE productos2 SET español='$proesp1',matematicas='$promat1',fisica='$profis1',productos_id='$propro1' WHERE id = '$proid1'");
echo "<script>window.location= 'calificaciones_tabla.php?pag=$pagina' </script>";
    
}
?>