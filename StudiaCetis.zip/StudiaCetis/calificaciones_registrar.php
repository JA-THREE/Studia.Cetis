<?php 
/*Se encarga de registrar calificaciones*/
include("conexion.php");
include("calificaciones_tabla.php");
$pagina = $_GET['pag'];
?>
<html>
<body>
<div class="caja_popup2">
<form class="contenedor_popup" method="POST">
<table>
<tr><th colspan="2">Agregar calificaciones</th></tr>	
<tr> 
<td><b>Español: </b></td>
<td><input type="text" name="txtesp" autocomplete="off" class="CajaTexto"></td>
</tr>
<tr> 
<td><b>Matematicas: </b></td>
<td><input type="text" name="txtmat" autocomplete="off" class="CajaTexto"></td>
</tr>
<tr> 
<td><b>Fisica: </b></td>
<td><input type="number" name="txtfis" autocomplete="off" class="CajaTexto" step="any"></td>
</tr>
<tr> 
<td><b>Alumno: </b></td>
<td>
<select name="txtpro" class='CajaTexto'>
<?php
		
$qrproductos = mysqli_query($conn, "SELECT * FROM productos ");
while($mostrarpro = mysqli_fetch_array($qrproductos)) 
{ 
echo '<option value="'.$mostrarpro['id'].'">' .$mostrarpro['nombre']. '</option>';
}
?>  
</select>
</td>
</tr>

<tr>
				
<td colspan="2" >
<?php echo "<a class='BotonesTeam' href=\"calificaciones_tabla.php?pag=$pagina\">Cancelar</a>";?>&nbsp;
<input class='BotonesTeam' type="submit" name="btnregistrar" value="Registrar" onClick="javascript: return confirm('¿Deseas registrar estas calificaciones ?');">
</td>
</tr>
</table>
</form>
</div>
</body>
</html>
<?php
	
if(isset($_POST['btnregistrar']))
{   
	$proesp 	= $_POST['txtesp'];
    $promat 	= $_POST['txtmat'];
	$profis 	= $_POST['txtfis'];
	$propro 	= $_POST['txtpro'];
   
	mysqli_query($conn, "INSERT INTO productos2(español,matematicas,fisica,productos_id) VALUES('$proesp','$promat','$profis','$propro')");
	
	echo "<script> alert('Calificaciones registradas con exito'); window.location='calificaciones_tabla.php' </script>";
}
?>