<?php 
/*Se encarga de mostrar las calificaciones*/
include("conexion.php");
include("calificaciones_tabla.php");
$pagina = $_GET['pag'];
$id = $_GET['id'];

$querybuscar = mysqli_query($conn, "SELECT pro2.id,español,matematicas,fisica,pro.nombre as productos 
FROM productos2 pro2, productos pro where pro2.productos_id=pro.id and pro2.id = '$id'");
 
while($mostrar = mysqli_fetch_array($querybuscar))
{
	$proid 	= $mostrar['id'];
	$proesp	= $mostrar['español'];
	$promat	= $mostrar['matematicas'];
	$profis	= $mostrar['fisica'];
	$propro	= $mostrar['productos'];
}
?>
<html>
<body>
<div class="caja_popup2">
<form class="contenedor_popup" method="POST">
<table>
<tr><th colspan="2">Ver Calificaciones</th></tr>
<tr> 
<td><b>Id:</b></td>
<td><?php echo $proid;?></td>
</tr>		
<tr> 
<td><b>Español: </b></td>
<td><?php echo $proesp;?></td>
</tr>
<tr> 
<td><b>Matematicas: </b></td>
<td><?php echo $promat;?></td>
</tr>
<tr> 
<td><b>Fisica: </b></td>
<td><?php echo $profis;?></td>
</tr>
<tr> 
<td><b>Alumno: </b></td>
<td><?php echo $propro;?></td>
</tr>

<tr>
				
<td colspan="2">
<?php echo "<a class='BotonesTeam' href=\"calificaciones_tabla.php?pag=$pagina\">Regresar</a>";?>
</td>
</tr>
</table>
</form>
</div>
</body>
</html>